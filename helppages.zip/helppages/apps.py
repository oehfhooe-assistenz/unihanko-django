from django.apps import AppConfig


class HelppagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'helppages'
